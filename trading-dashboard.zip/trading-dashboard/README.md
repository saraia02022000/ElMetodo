# Trading Dashboard

Dashboard profesional para análisis técnico y screening de empresas con indicadores ATR dinámicos.

## ✨ Características

- **Dashboard de análisis**: Análisis en tiempo real de un ticker con 5 condiciones de entrada
- **Screener de empresas**: Evalúa múltiples símbolos según condiciones y las clasifica por score (0-5)
- **Indicadores técnicos**: EMA20, EMA50, EMA200 (diario y 4H), RSI14, ATR14
- **Estrategia ATR dinámico**: 
  - TP = EMA50 + 2×ATR
  - SL = EMA50 - 1×ATR
  - Ratio RR: 2:1
- **5 Condiciones de entrada**:
  1. Precio > EMA200 Diario (tendencia macro alcista)
  2. EMA20 > EMA50 en 4H (momentum alineado)
  3. Precio toca EMA50 ±2% (pullback válido)
  4. RSI entre 35-60 en 4H (retroceso sano)
  5. Mínimo día anterior > EMA50 ±2% (validación adicional)
- **Conversión de divisas**: USD/EUR automático desde Banco Central Europeo
- **Análisis rápido**: 1 consulta/segundo (respeta límites de API: 8/minuto)
- **Colores por score**: Visualización inmediata (rojo ❌ a verde ✅)
- **Carga de archivos**: Soporta .txt y .csv con listas de símbolos

## 🚀 Cómo usar

### En línea (Netlify)
1. Ve a [tu-dominio.netlify.app](https://tu-dominio.netlify.app)
2. Obtén API key gratuita en [twelvedata.com](https://twelvedata.com)
3. Pega tu API key
4. Busca tickers o análisis empresas

### Localmente
1. Clona el repositorio
2. Abre `index.html` en el navegador
3. ¡Listo! (funciona completamente offline excepto por datos)

## 🔧 Tecnología

- **HTML5 + Vanilla JavaScript**
- **API**: Twelve Data (8 consultas/minuto gratis)
- **Tipos de cambio**: Banco Central Europeo (BCE)
- **Sin frameworks**: Funciona en cualquier navegador moderno

## 📋 Requisitos

- Navegador moderno (Chrome, Safari, Firefox, Edge)
- API key de Twelve Data (gratis en https://twelvedata.com)

## 📱 Responsive

- ✅ Desktop
- ✅ Tablet  
- ✅ iPhone/iPad (modo app con "Añadir a pantalla de inicio")
- ✅ Modo oscuro/claro automático

## 📊 Ejemplo de uso

```
Entrada: $10.22 (ONDS)
ATR: 0.68

TP = $10.22 + (2 × 0.68) = $11.58
SL = $10.22 - (1 × 0.68) = $9.54
Ratio: 2:1
```

## 🔐 Privacidad

- API key guardada **solo en tu dispositivo** (localStorage)
- Tipo de cambio guardado localmente
- Sin servidores backend
- Sin envío de datos a terceros

## 📈 Screener

Analiza hasta 60 empresas por minuto:
1. Pega lista de tickers (AAPL, MSFT, GOOGL, etc.)
2. Haz clic en "Iniciar Análisis"
3. Visualiza resultados en tiempo real

Colores:
- 🔴 0-1: Sin condiciones
- 🟠 2: Pocas condiciones
- 🟡 3: Medio
- 🟢 4: Bien
- 🟢 5: Excelente

## 📄 Archivos

- `index.html` - App completa (todas las características incluidas)

## ⚖️ Licencia

Código libre para usar, modificar y distribuir.

## 📞 Soporte

Para errores o sugerencias, crea un issue en GitHub.

---

**Última actualización**: Junio 2026
